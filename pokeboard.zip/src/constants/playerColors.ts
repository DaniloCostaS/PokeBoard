export const PLAYER_COLORS = [
    '#e74c3c', '#3498db', '#f1c40f', '#9b59b6', 
    '#1abc9c', '#e67e22', '#34495e', '#ff7979'
];