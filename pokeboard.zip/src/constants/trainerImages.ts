export const TRAINER_IMAGES = [
    { label: "Red", file: "Red.png" },
    { label: "Blue", file: "Blue.png" },
    { label: "Lucas", file: "Lucas.png"},
    { label: "Dawn", file: "Dawn.png" },
    { label: "Barry", file: "Barry.png" },
    { label: "Brendan", file: "Brendan.png"},
    { label: "May", file: "May.png" },
    { label: "Ethan", file: "Ethan.png" },
    { label: "OAK", file: "Oak.png" }
];