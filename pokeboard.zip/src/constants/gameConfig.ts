export const TILE = { 
    PATH: 0, GRASS: 1, WATER: 2, GROUND: 3, CITY: 4, GYM: 5, EVENT: 6,
    ROCKET: 7, BIKER: 8, YOUNG: 9, OLD: 10
};