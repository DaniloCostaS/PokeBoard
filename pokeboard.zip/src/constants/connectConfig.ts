export const firebaseConfig = {
  apiKey: "AIzaSyBdV8_HMXwX7K9IaxWExxK3wzpI2UjfYeM",
  authDomain: "pokemonmasterboard.firebaseapp.com",
  databaseURL: "https://pokemonmasterboard-default-rtdb.firebaseio.com/",
  projectId: "pokemonmasterboard",
  storageBucket: "pokemonmasterboard.firebasestorage.app",
  messagingSenderId: "949731697037",
  appId: "1:949731697037:web:76a03b5b65dc9cf80c5dc4"
};